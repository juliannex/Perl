# !usr\bin\perl

#Confirm if the person wants to play
$Play = 1; 
while ($Play == 1) { 
  print ("Do you wish to play tic tac toe? Please answer Y or N\n"); 
  #get answer
  chomp($Answer = <STDIN>); 
  #answer no, exit loop
  if ( $Answer eq "N" || $Answer eq "n") { 
    print ("Ok, goodbye!\n"); 
    $Play = 0; 
  } 
  #answer not clear, prompt for answer again
  if ( $Answer ne "N" && $Answer ne "n" && $Answer ne "Y" && $Answer ne "y") { 
    print ("Give me a yes or no answer next time, please!\n"); 
  } 
  #answer yes, play the game
  if ( $Answer eq "Y" || $Answer eq "y") { 
     #initialize playing board
     @Board = (" ", " ", " ", " ", " ", " ", " ", " ", " "); 
     @BestMoves = (5, 1, 3, 7, 9); 
     @OtherMoves = (2, 4, 6, 8);
   
     ($MySym, $PcSym) = ChooseSym();
     print ("Enter '1'- You start first; Else - computer starts first.\n"); 
     chomp($start = <STDIN>); 
     if($start ==1){
       $first = \&GetHumanMove;
       $fSym = $MySym;
       $second = \&GetComputerMove;
       $sSym = $PcSym;
       print ("You start first!\n");
     }
     else{
       $first = \&GetComputerMove;
       $fSym = $PcSym;
       $second = \&GetHumanMove;
       $sSym = $MySym;
       print ("Computer starts first!\n");
     }
     
     #start game
     $Winner = 0; 
     $Moves = 0;
     while ( $Winner != 1 ) {
 
        $Answer = &{$first};
        $Position = $Answer - 1; 
        $Board[$Position] = $fSym; 
        $Moves++;
        DisplayBoard(); 
        $Winner = CheckForWinner(); 
        if ($Winner >=1) {last}; 

        $Answer = &{$second}; 
        $Position = $Answer - 1; 
        $Board[$Position] = $sSym; 
        $Moves++;
        DisplayBoard(); 
        $Winner = CheckForWinner(); 
        if ($Winner >= 1) {last}; 
    } 

    if ($Winner ==1) {print ("$MySym is a winner!!! \a\n")}; #Rings when Human wins

    if ($Winner ==2) {print ("$PcSym is a winner!!! \n")}; 

    if ($Winner ==3) {print ("There is a draw!!! \n")};
  } 
} 


#### Subroutines ####

sub ChooseSym{
  $MySym = undef; $PcSym =undef;
  print ("Please choose '1' for cross, '2' for naught.\n"); 
  chomp($MySym = <STDIN>); 
   if($MySym ==1){
    print ("You are 'X', computer is 'O'!\n");
    return ("X", "O")
   }
   elsif($MySym ==2){
     print ("You are 'O', computer is 'X'!\n");
     return ("O", "X")
   }
   else{
     ChooseSym();
   }
}

sub DisplayBoard{ 
  print ("-------\n"); 
  print ("|$Board[0]|$Board[1]|$Board[2]|\n");
  print ("-------\n");
  print ("|$Board[3]|$Board[4]|$Board[5]|\n"); 
  print ("-------\n");
  print ("|$Board[6]|$Board[7]|$Board[8]|\n"); 
  print ("-------\n"); 
} 

sub GetComputerMove{ 
  $PcMove = 0;
 
  $Factor = 10;		# set computer not-doing-perfect factor
  $r = int (rand $Factor); 

  $PcMove = &WinMove(); #always checking for winning move
  if($PcMove != 0){
  return $PcMove  };
    
  if($r != 0){     	#if random number is '0', computer will overlook a human winning move
    $PcMove = &BlockMove();
    if($PcMove != 0){
      return $PcMove  };
  }

  if($r != 1 && $r != 2){  #if random number is '1', '2', computer will miss a best move
    $PcMove = &BestMove();
    if($PcMove != 0){
      return $PcMove  };
  }

  for ($i = 1; $i<=9 ; $i++){ 
    if ( $Board[$i-1] eq " " ){ 
      $PcMove = $i; 
      last;  } 
  } 
  return $PcMove; 
}

#will be called by &GetComputerMove
sub BestMove{
  $Move =0;
  foreach $i (@BestMoves){ 
    if ( $Board[$i-1] eq " " ){ 
    $Move = $i; 
    last; } 
  } 
  return $Move;
}

#will be called by &BlockMove
sub OtherMove{
  $Move =0;
  foreach $i (@OtherMoves){ 
    if ( $Board[$i-1] eq " " ){ 
    $Move = $i; 
    last; } 
  } 
  return $Move;
}

#will be called by &GetComputerMove
#find winning move
sub WinMove{
  $PcMove=0;
  if ($Board[0] eq $PcSym && $Board[1] eq $PcSym && $Board[2] eq " ") {
    $PcMove = 3;  }
  elsif ($Board[0] eq $PcSym && $Board[3] eq $PcSym && $Board[6] eq " ") {
    $PcMove = 7;  }
  elsif ($Board[0] eq $PcSym && $Board[4] eq $PcSym && $Board[8] eq " ") {
    $PcMove = 9;  }
  elsif ($Board[1] eq $PcSym && $Board[2] eq $PcSym && $Board[0] eq " ") {
    $PcMove = 1;  }
  elsif ($Board[1] eq $PcSym && $Board[4] eq $PcSym && $Board[7] eq " ") {
    $PcMove = 8;  }
  elsif ($Board[2] eq $PcSym && $Board[4] eq $PcSym && $Board[6] eq " ") {
    $PcMove = 7;  }
  elsif ($Board[2] eq $PcSym && $Board[5] eq $PcSym && $Board[8] eq " ") {
    $PcMove = 9;  }
  elsif ($Board[3] eq $PcSym && $Board[6] eq $PcSym && $Board[0] eq " ") {
    $PcMove = 1;  }
  elsif ($Board[3] eq $PcSym && $Board[4] eq $PcSym && $Board[5] eq " ") {
    $PcMove = 6;  }
  elsif ($Board[4] eq $PcSym && $Board[5] eq $PcSym && $Board[3] eq " ") {
    $PcMove = 4;  }
  elsif ($Board[4] eq $PcSym && $Board[6] eq $PcSym && $Board[2] eq " ") {
    $PcMove = 3;  }
  elsif ($Board[4] eq $PcSym && $Board[7] eq $PcSym && $Board[1] eq " ") {
    $PcMove = 2;  }
  elsif ($Board[4] eq $PcSym && $Board[8] eq $PcSym && $Board[0] eq " ") {
    $PcMove = 1;  }
  elsif ($Board[5] eq $PcSym && $Board[8] eq $PcSym && $Board[2] eq " ") {
    $PcMove = 3;  }
  elsif ($Board[6] eq $PcSym && $Board[7] eq $PcSym && $Board[8] eq " ") {
    $PcMove = 9;  }
  elsif ($Board[7] eq $PcSym && $Board[8] eq $PcSym && $Board[6] eq " " ) {
    $PcMove = 7;  }
  elsif ($Board[0] eq $PcSym && $Board[2] eq $PcSym && $Board[1] eq " ") {
    $PcMove = 2;  }
  elsif ($Board[3] eq $PcSym && $Board[5] eq $PcSym && $Board[4] eq " ") {
    $PcMove = 5;  }
  elsif ($Board[6] eq $PcSym && $Board[8] eq $PcSym && $Board[7] eq " ") {
    $PcMove = 8;  }
  elsif ($Board[0] eq $PcSym && $Board[6] eq $PcSym && $Board[3] eq " ") {
    $PcMove = 4;  }
  elsif ($Board[1] eq $PcSym && $Board[7] eq $PcSym && $Board[4] eq " ") {
    $PcMove = 5;  }
  elsif ($Board[2] eq $PcSym && $Board[8] eq $PcSym && $Board[5] eq " ") {
    $PcMove = 6;  }
  elsif ($Board[0] eq $PcSym && $Board[8] eq $PcSym && $Board[4] eq " ") {
    $PcMove = 5;  }
  elsif ($Board[2] eq $PcSym && $Board[6] eq $PcSym && $Board[4] eq " ") {
    $PcMove = 5;  }
  return $PcMove;
}

#will be called by &GetComputerMove
#prevent component from winning
sub BlockMove {
  $PcMove=0;
  if ($Board[0] eq $MySym && $Board[1] eq $MySym && $Board[2] eq " ") {
    $PcMove = 3;  }
  elsif ($Board[0] eq $MySym && $Board[3] eq $MySym && $Board[6] eq " ") {
    $PcMove = 7;  }
  elsif ($Board[0] eq $MySym && $Board[4] eq $MySym && $Board[8] eq " ") {
    $PcMove = 9;  }
  elsif ($Board[1] eq $MySym && $Board[2] eq $MySym && $Board[0] eq " ") {
    $PcMove = 1;  }
  elsif ($Board[1] eq $MySym && $Board[4] eq $MySym && $Board[7] eq " ") {
    $PcMove = 8;  }
  elsif ($Board[2] eq $MySym && $Board[4] eq $MySym && $Board[6] eq " ") {
    $PcMove = 7;  }
  elsif ($Board[2] eq $MySym && $Board[5] eq $MySym && $Board[8] eq " ") {
    $PcMove = 9;  }
  elsif ($Board[3] eq $MySym && $Board[6] eq $MySym && $Board[0] eq " ") {
    $PcMove = 1;  }
  elsif ($Board[3] eq $MySym && $Board[4] eq $MySym && $Board[5] eq " ") {
    $PcMove = 6;  }
  elsif ($Board[4] eq $MySym && $Board[5] eq $MySym && $Board[3] eq " ") {
    $PcMove = 4;  }
  elsif ($Board[4] eq $MySym && $Board[6] eq $MySym && $Board[2] eq " ") {
    $PcMove = 3;  }
  elsif ($Board[4] eq $MySym && $Board[7] eq $MySym && $Board[1] eq " ") {
    $PcMove = 2;  }
  elsif ($Board[4] eq $MySym && $Board[8] eq $MySym && $Board[0] eq " ") {
    $PcMove = 1;  }
  elsif ($Board[5] eq $MySym && $Board[8] eq $MySym && $Board[2] eq " ") {
    $PcMove = 3;  }
  elsif ($Board[6] eq $MySym && $Board[7] eq $MySym && $Board[8] eq " ") {
    $PcMove = 9;  }
  elsif ($Board[7] eq $MySym && $Board[8] eq $MySym && $Board[6] eq " " ) {
    $PcMove = 7;  }
  elsif ($Board[0] eq $MySym && $Board[2] eq $MySym && $Board[1] eq " ") {
    $PcMove = 2;  }
  elsif ($Board[3] eq $MySym && $Board[5] eq $MySym && $Board[4] eq " ") {
    $PcMove = 5;  }
  elsif ($Board[6] eq $MySym && $Board[8] eq $MySym && $Board[7] eq " ") {
    $PcMove = 8;  }
  elsif ($Board[0] eq $MySym && $Board[6] eq $MySym && $Board[3] eq " ") {
    $PcMove = 4;  }
  elsif ($Board[1] eq $MySym && $Board[7] eq $MySym && $Board[4] eq " ") {
    $PcMove = 5;  }
  elsif ($Board[2] eq $MySym && $Board[8] eq $MySym && $Board[5] eq " ") {
    $PcMove = 6;  }
  elsif ($Board[0] eq $MySym && $Board[8] eq $MySym && $Board[4] eq " ") {
    $PcMove = 5;  }
  elsif ($Board[2] eq $MySym && $Board[6] eq $MySym && $Board[4] eq " ") {
    $PcMove = 5;  }
  elsif ($Board[0] eq $MySym && $Board[8] eq $MySym ) {
    $PcMove = OtherMove();  }
  elsif ($Board[2] eq $MySym && $Board[6] eq $MySym ) {
    $PcMove = OtherMove();  }
  return $PcMove;
}

sub GetHumanMove{  
  # assume human makes bad moves 
  $OkMove = 0; 
  # while human continues to give bad stuff 
  while ($OkMove == 0) { 
    print ("What is your next move? Please enter 1-9\n"); 
    chomp($i = <STDIN>); 
    if ($i > 0 && $i < 10) { 
    # input ok so see if board occupied 
      if ( $Board[$i-1] ne " ") { 
        $OkMove = 0; 
        print ("Bad Move! Give me a valid one!\n"); 
        DisplayBoard(); 
      } 
      else { 
      # indicate move is ok and return it 
      $OkMove = 1; 
      $MyMove = $i; 
      } 
    } 
    else { 
    # input bad so indicate 
    $OkMove = 0; 
    print ("Number must be 1 through 9!\n"); 
    } 
  } 
  return $MyMove; 
}

sub CheckForWinner{ 
#check if Human is a winner 
  if ($Board[0] eq $MySym && $Board[1] eq $MySym && $Board[2] eq $MySym ){return 1}; 
  if ($Board[3] eq $MySym && $Board[4] eq $MySym && $Board[5] eq $MySym ){return 1}; 
  if ($Board[6] eq $MySym && $Board[7] eq $MySym && $Board[8] eq $MySym ){return 1}; 
  if ($Board[0] eq $MySym && $Board[3] eq $MySym && $Board[6] eq $MySym ){return 1}; 
  if ($Board[1] eq $MySym && $Board[4] eq $MySym && $Board[7] eq $MySym ){return 1}; 
  if ($Board[2] eq $MySym && $Board[5] eq $MySym && $Board[8] eq $MySym ){return 1}; 
  if ($Board[0] eq $MySym && $Board[4] eq $MySym && $Board[8] eq $MySym ){return 1}; 
  if ($Board[2] eq $MySym && $Board[4] eq $MySym && $Board[6] eq $MySym ){return 1}; 

#check if Computer is a winner 
  if ($Board[0] eq $PcSym && $Board[1] eq $PcSym && $Board[2] eq $PcSym ){return 2}; 
  if ($Board[3] eq $PcSym && $Board[4] eq $PcSym && $Board[5] eq $PcSym ){return 2}; 
  if ($Board[6] eq $PcSym && $Board[7] eq $PcSym && $Board[8] eq $PcSym ){return 2}; 
  if ($Board[0] eq $PcSym && $Board[3] eq $PcSym && $Board[6] eq $PcSym ){return 2}; 
  if ($Board[1] eq $PcSym && $Board[4] eq $PcSym && $Board[7] eq $PcSym ){return 2}; 
  if ($Board[2] eq $PcSym && $Board[5] eq $PcSym && $Board[8] eq $PcSym ){return 2}; 
  if ($Board[0] eq $PcSym && $Board[4] eq $PcSym && $Board[8] eq $PcSym ){return 2}; 
  if ($Board[2] eq $PcSym && $Board[4] eq $PcSym && $Board[6] eq $PcSym ){return 2}; 

#check if a draw  
  if ($Moves >= 9) {return 3};
} 


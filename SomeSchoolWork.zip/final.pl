#!/usr/bin/perl
 # notice that point 0,0 is upper left corner!
 use Tk;

 my $mw = MainWindow->new;
 $mw->title('Draw Polynomial');

 $canvas = $mw->Canvas(width=>700, height=>500, background=>yellow)->pack();

 #draw X-Y coordinate axis
 $canvas->createLine(25, 250, 670, 250); 
 $canvas->createText(10, 250, -fill => 'black', -text => 'X'); 
 $canvas->createLine(350, 25, 350, 670); 
 $canvas->createText(350, 10, -fill => 'black', -text => 'Y'); 


 $label = $mw->Label(-text => 'Type in Your Polynomial Expressions: ');
 $label->pack(-side => 'left');
 
 my $str;
 $entry = $mw->Entry(-textvariable => \$str);
 $entry->pack(-side => 'left');
 $entry->bind ('<Return>' => \&draw );
 $entry->configure (-width => 70);

 $button = $mw->Button(-text => 'EXIT', -command =>\&exit, -width=>12);
 $button->pack(-side => 'right');
 
 MainLoop;

# Basic subroutine which prints out a message then exits.
 sub draw {
    my $exp;
    $exp =$str;
    $exp =~ s/\s//g;   #remove any space
    $exp =~ s/([a-zA-Z])/\$x/g;	        #substitute variable with $x
    $exp =~ s/(\d)(\$[a-zA-Z])/$1*$2/g; print $exp;
		
	my $x1, $y1, $x2, $y2;
	for ($x = 0.1; $x < 200;)
	{
	    $x1 = 20*$x +350; $y1 = -evalPly($exp, $x) * 20 + 250;  #enlarge by 20 times
		$x2 = 20*++$x +350; $y2 = -evalPly($exp, $x)* 20 + 250; #enlarge by 20 times
	    $canvas->create ('line', 
             $x1, $y1,
			 $x2, $y2,
             -fill => 'Blue');
		
	}

 }
 
sub evalPly{
   ($s, $v) = @_;
    $x = $v;
	return eval $s;
}